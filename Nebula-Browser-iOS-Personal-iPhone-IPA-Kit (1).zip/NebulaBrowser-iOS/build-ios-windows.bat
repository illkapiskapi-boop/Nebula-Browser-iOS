@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem Relaunch in a persistent Command Prompt window when double-clicked.
if /i not "%~1"=="--inside" (
    start "NEBULA BROWSER - iPHONE IPA BUILDER" "%ComSpec%" /k ""%~f0" --inside"
    exit /b
)

cd /d "%~dp0"
title NEBULA BROWSER - iPHONE IPA BUILDER
cls

echo ============================================================
echo             NEBULA BROWSER FOR iPHONE
echo            WINDOWS - GITHUB MAC BUILDER
echo ============================================================
echo.
echo This creates an unsigned device IPA on a GitHub-hosted Mac.
echo You will sign and install it on your iPhone with Sideloadly.
echo It does NOT create a simulator-only app.
echo.
echo IMPORTANT:
echo  - Do not send your Apple ID password or verification codes to anyone.
echo  - A free Apple ID signature normally expires after 7 days.
echo  - This builder does not need your Apple signing credentials.
echo.

echo [1/4] Checking GitHub CLI...
where gh >nul 2>nul
if errorlevel 1 goto GH_MISSING
for /f "delims=" %%V in ('gh --version 2^>nul') do echo %%V
echo [OK] GitHub CLI found.
echo.

echo [2/4] Checking GitHub login...
gh auth status --hostname github.com >nul 2>&1
if errorlevel 1 goto GH_LOGIN
echo [OK] GitHub account is authorized.
echo.

set "REPO=illkapiskapi-boop/Nebula-Browser-iOS"
set /p "REPO=GitHub repository [illkapiskapi-boop/Nebula-Browser-iOS]: "
if not defined REPO set "REPO=illkapiskapi-boop/Nebula-Browser-iOS"
set "BRANCH=main"
set /p "BRANCH=Branch [main]: "
if not defined BRANCH set "BRANCH=main"

echo.
echo [3/4] Checking device IPA workflow on %REPO% branch %BRANCH%...
gh workflow view ios-device-ipa.yml --repo "%REPO%" --ref "%BRANCH%"
if errorlevel 1 goto WORKFLOW_MISSING

echo.
echo Starting remote iPhone device build on GitHub Actions...
gh workflow run ios-device-ipa.yml --repo "%REPO%" --ref "%BRANCH%"
if errorlevel 1 goto START_FAILED

echo.
echo Waiting for GitHub to register the run...
set "RUN_ID="
for /l %%N in (1,1,12) do (
    timeout /t 5 /nobreak >nul
    for /f "delims=" %%I in ('gh run list --workflow ios-device-ipa.yml --repo "%REPO%" --branch "%BRANCH%" --event workflow_dispatch --limit 1 --json databaseId --jq "[0].databaseId" 2^>nul') do set "RUN_ID=%%I"
    if defined RUN_ID if not "!RUN_ID!"=="null" goto GOT_RUN
)
goto RUN_NOT_FOUND

:GOT_RUN
echo.
echo Workflow run ID: %RUN_ID%
echo [4/4] Waiting for the iPhone build to finish...
gh run watch %RUN_ID% --repo "%REPO%" --exit-status
if errorlevel 1 goto BUILD_FAILED

set "OUT=%~dp0build-output"
if not exist "%OUT%" mkdir "%OUT%"
echo.
echo Downloading unsigned device IPA artifact...
gh run download %RUN_ID% --repo "%REPO%" --name NebulaBrowser-iOS-Unsigned-IPA --dir "%OUT%"
if errorlevel 1 goto DOWNLOAD_FAILED

if not exist "%OUT%\NebulaBrowser-Unsigned-iOS.ipa" goto IPA_MISSING

echo.
echo ============================================================
echo              DEVICE IPA BUILD SUCCESSFUL
echo ============================================================
echo File:
echo %OUT%\NebulaBrowser-Unsigned-iOS.ipa
echo.
echo NEXT: Open Sideloadly on Windows, load this IPA, connect your iPhone,
echo and sign/install it using your own Apple ID inside Sideloadly.
echo Do not share your Apple ID password or verification codes.
start "" "%OUT%"
goto FINISH

:GH_MISSING
echo.
echo [ERROR] GitHub CLI is not installed.
echo Install it from https://cli.github.com/ then run: gh auth login
goto FINISH

:GH_LOGIN
echo.
echo [ERROR] GitHub CLI is not signed in.
echo Run: gh auth login
goto FINISH

:WORKFLOW_MISSING
echo.
echo [ERROR] ios-device-ipa.yml was not found.
echo Upload the project contents to the repository, including:
echo .github\workflows\ios-device-ipa.yml
start "" "https://github.com/%REPO%/tree/%BRANCH%/.github/workflows"
goto FINISH

:START_FAILED
echo.
echo [ERROR] GitHub could not start the workflow.
echo Check that GitHub Actions is enabled and that you have write access.
goto FINISH

:RUN_NOT_FOUND
echo.
echo [ERROR] The workflow was triggered, but its run ID was not found.
echo Open: https://github.com/%REPO%/actions/workflows/ios-device-ipa.yml
goto FINISH

:BUILD_FAILED
echo.
echo [ERROR] The remote iPhone build failed.
echo Open the Actions page and inspect the failed job:
start "" "https://github.com/%REPO%/actions/workflows/ios-device-ipa.yml"
goto FINISH

:DOWNLOAD_FAILED
echo.
echo [ERROR] Build finished, but the artifact download failed.
echo Download NebulaBrowser-iOS-Unsigned-IPA from the workflow run manually.
goto FINISH

:IPA_MISSING
echo.
echo [ERROR] The artifact was downloaded, but the IPA file is missing.
echo Check the GitHub Actions artifact contents.
goto FINISH

:FINISH
echo.
echo ============================================================
echo The builder has finished. This window will remain open.
echo ============================================================
echo.
pause
exit /b
