# ☄ Nebula Browser for iOS

**Browse beyond the ordinary.** A violet nebula-inspired browser for iPhone and iPad, built with UIKit and Apple's WebKit (`WKWebView`).

## Features

- Dark violet Nebula interface with rounded controls and a subtle animated glow.
- Violet, Aurora Blue, and Cosmic Rose themes.
- DuckDuckGo search and URL bar.
- Multi-tab browsing.
- Browsing history with search, deletion, and clear-all.
- Bookmarks.
- File downloads and the iOS share sheet.
- Local browser data.
- Memory-conscious tab model: only the active `WKWebView` is kept alive; other tabs reload from their saved URL when selected.

## iOS compatibility

This Xcode project targets **iOS 15 and later**. It does not support iOS 11–14. The app uses Apple's `WKWebView` (WebKit), not a bundled Chromium engine.

## Build an iPhone IPA from Windows

Windows cannot compile iOS apps locally. The included GitHub Actions workflow uses a GitHub-hosted Mac runner and creates an **unsigned device IPA** (not a Simulator app):

1. Upload the contents of this project folder to your GitHub repository. Keep `.github/workflows/ios-device-ipa.yml` in place.
2. Install [GitHub CLI](https://cli.github.com/) and sign in once with `gh auth login`.
3. Run `build-ios-windows.bat` and enter your `owner/repository` and branch (usually `main`).
4. The script starts the `Build Nebula Browser for iPhone (unsigned IPA)` workflow and downloads `NebulaBrowser-Unsigned-iOS.ipa` into `build-output`.

The workflow builds for `generic/platform=iOS`, using the `iphoneos` SDK. It packages the app as an IPA but deliberately does **not** sign it, so no Apple certificate, password, or provisioning-profile secret is stored in GitHub.

## Sign and install it on your own iPhone (Windows)

For a personal device without a paid Apple Developer membership, one practical route is to use a local sideloading signer such as [Sideloadly](https://sideloadly.io/). Sideloadly's own documentation says it can sign/install an IPA with a free Apple ID. Follow its current official Windows setup instructions:

1. Download Sideloadly only from its official website.
2. Connect your iPhone to the Windows PC by USB and tap **Trust This Computer** on the iPhone if prompted.
3. Open Sideloadly and select `build-output/NebulaBrowser-Unsigned-iOS.ipa`.
4. Select your connected iPhone.
5. Enter your own Apple Account in Sideloadly's sign-in field, then start the sideload. **Never send your Apple Account password or verification codes to another person or to this repository.** If a parent/guardian manages your Apple Account, ask them to help with this step.
6. On iOS 16 or later, if prompted, enable Developer Mode under **Settings → Privacy & Security → Developer Mode**, then restart and confirm.
7. If iOS asks you to trust the developer, open **Settings → General → VPN & Device Management** and trust the profile associated with your Apple Account.

### Free-account limitations

Apple's Personal Team provisioning profiles expire after **7 days**. Apple also documents limits of 10 App IDs, 3 registered devices, and up to 3 installed apps per device for a free Personal Team. You must re-sign/reinstall periodically to keep the app working. Sideloadly documents automatic refresh support, but it requires the computer/device to be available for refresh. See Apple's account guide and Sideloadly's official FAQ below.

A permanently valid installable IPA is not available with a free Personal Team. Longer-lived Ad Hoc distribution requires the Apple Developer Program, an eligible signing certificate, and a provisioning profile containing the device UDID.

## Build on a Mac with Xcode

Open `NebulaBrowser.xcodeproj`, select the `NebulaBrowser` scheme, choose your Apple Development team under **Signing & Capabilities**, connect your iPhone, and press **Run**. With a free Personal Team this is a direct development install and must be re-provisioned periodically.

## Project structure

```text
NebulaBrowser-iOS/
├── NebulaBrowser.xcodeproj/
├── NebulaBrowser/
├── .github/workflows/
│   ├── ios-build.yml          # Simulator .app workflow
│   └── ios-device-ipa.yml     # iPhone device IPA workflow (unsigned)
├── build-ios-mac.sh
└── build-ios-windows.bat
```

## Official references

- [Apple: Developer account overview and Personal Team limits](https://developer.apple.com/help/account/basics/about-your-developer-account/)
- [Apple: Create a development provisioning profile](https://developer.apple.com/help/account/provisioning-profiles/create-a-development-provisioning-profile/)
- [Apple: Xcode distribution methods](https://help.apple.com/xcode/mac/current/en.lproj/dev31de635e5.html)
- [Sideloadly official site](https://sideloadly.io/)
- [Sideloadly official FAQ](https://sideloadly.io/faq.html)

---

## Русский

### Сборка IPA для личного iPhone

На Windows Xcode локально не запускается. Поэтому `build-ios-windows.bat` запускает сборку на облачном Mac через GitHub Actions. Результат — **IPA для настоящего устройства, но без подписи**. Это не симуляторная `.app`.

Дальше подпись выполняется локально на твоём Windows-компьютере через официальный установщик [Sideloadly](https://sideloadly.io/): загрузи IPA, подключи свой iPhone по USB и используй собственный Apple Account внутри программы. Не отправляй пароль или коды подтверждения никому. Если аккаунтом управляет родитель или опекун, попроси его помочь с этим шагом.

На iOS 16 и новее может потребоваться включить **Настройки → Конфиденциальность и безопасность → Режим разработчика**. Если iOS попросит доверять профилю, открой **Настройки → Основные → VPN и управление устройством**.

**Ограничение бесплатной подписи:** профили Personal Team от Apple действуют 7 дней. После этого Nebula нужно переподписать/переустановить. Apple также указывает ограничения: до 10 App IDs, 3 зарегистрированных устройства и 3 одновременно установленных приложения на устройство. Sideloadly описывает автоматическое обновление подписи, когда компьютер и телефон доступны для обновления.

Для IPA с более длительным сроком действия требуется платная программа Apple Developer Program, сертификат и provisioning profile с UDID устройства. Текущий сборщик намеренно не запрашивает и не сохраняет твой Apple-пароль, сертификаты или приватные ключи в GitHub.

### Как получить IPA

1. Загрузи все файлы проекта в GitHub вместе с `.github/workflows/ios-device-ipa.yml`.
2. Установи [GitHub CLI](https://cli.github.com/) и выполни `gh auth login`.
3. Запусти `build-ios-windows.bat`, укажи репозиторий и ветку `main`.
4. Готовый `NebulaBrowser-Unsigned-iOS.ipa` появится в `build-output`.
5. Подпиши и установи этот IPA на свой iPhone через Sideloadly с собственным Apple Account.

**Совместимость:** проект рассчитан на iOS 15 и новее. iOS 11–14 не поддерживается этой версией Xcode-проекта.

*Explore the web. Discover your universe.* 💜
