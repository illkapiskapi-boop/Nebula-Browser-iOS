#!/usr/bin/env bash
# Nebula Browser iOS simulator builder (requires macOS + Xcode).
set -Eeuo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
PROJECT="$ROOT/NebulaBrowser.xcodeproj"
SCHEME="NebulaBrowser"
DERIVED="$ROOT/build"
APP="$DERIVED/Build/Products/Debug-iphonesimulator/NebulaBrowser.app"

finish() {
  status=$?
  echo
  if [[ $status -eq 0 ]]; then
    echo "============================================================"
    echo "                 BUILD SUCCESSFUL"
    echo "============================================================"
    echo "Simulator app: $APP"
    echo "Open this .app in an iOS Simulator; it is not an installable IPA."
  else
    echo "============================================================"
    echo "                   BUILD FAILED"
    echo "============================================================"
    echo "Read the Xcode error messages above."
  fi
  echo
  read -r -p "Press Enter to close this window... " _ || true
  exit "$status"
}
trap finish EXIT

printf '\n============================================================\n'
printf '              NEBULA BROWSER FOR iOS\n'
printf '              MAC BUILD SCRIPT\n'
printf '============================================================\n\n'

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "[ERROR] This script must run on macOS. iOS apps cannot be compiled locally on Windows."
  exit 1
fi
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "[ERROR] Xcode command-line tools were not found. Install/open Xcode, then run: xcode-select --install"
  exit 1
fi
if [[ ! -d "$PROJECT" ]]; then
  echo "[ERROR] NebulaBrowser.xcodeproj was not found next to this script."
  exit 1
fi

echo "[1/3] Checking Xcode..."
xcodebuild -version

echo
echo "[2/3] Building for iOS Simulator..."
xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  -configuration Debug \
  -derivedDataPath "$DERIVED" \
  CODE_SIGNING_ALLOWED=NO \
  build

echo
echo "[3/3] Checking build output..."
if [[ ! -d "$APP" ]]; then
  echo "[ERROR] Xcode completed but the .app output was not found:"
  echo "$APP"
  exit 1
fi
