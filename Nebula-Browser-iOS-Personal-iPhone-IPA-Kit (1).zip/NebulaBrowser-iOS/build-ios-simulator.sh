#!/usr/bin/env bash
# Backwards-compatible name; delegates to the pause-friendly Mac builder.
ROOT="$(cd "$(dirname "$0")" && pwd)"
exec "$ROOT/build-ios-mac.sh" "$@"
